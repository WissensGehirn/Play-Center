import tkinter as tk
from tkinter import filedialog, messagebox
import subprocess
import json
import os

# Pfad zur Speicherdatei
SAVE_FILE = "games.json"

# Lade gespeicherte Spiele
def load_games():
    if os.path.exists(SAVE_FILE):
        with open(SAVE_FILE, "r") as f:
            return json.load(f)
    return []

# Speichere Spiele
def save_games():
    with open(SAVE_FILE, "w") as f:
        json.dump(games, f, indent=4)

# Starte Spiel
def start_game(path):
    try:
        subprocess.Popen(path, shell=True)
    except Exception as e:
        messagebox.showerror("Fehler", f"Spiel konnte nicht gestartet werden:\n{e}")

# Spiel hinzufügen
def add_game():
    path = filedialog.askopenfilename(
        title="Spiel auswählen",
        filetypes=[("Spiele", "*.exe *.lnk"), ("Alle Dateien", "*.*")]
    )
    if path:
        name = simple_input("Spielname", "Gib einen Namen für das Spiel ein:")
        if name:
            games.append({"name": name, "path": path})
            save_games()
            refresh_list()

# Spiel löschen
def delete_game():
    selected = game_listbox.curselection()
    if selected:
        index = selected[0]
        del games[index]
        save_games()
        refresh_list()

# Eingabedialog
def simple_input(title, prompt):
    input_window = tk.Toplevel(root)
    input_window.title(title)
    tk.Label(input_window, text=prompt).pack(padx=10, pady=5)
    entry = tk.Entry(input_window)
    entry.pack(padx=10, pady=5)
    result = []

    def confirm():
        result.append(entry.get())
        input_window.destroy()

    tk.Button(input_window, text="OK", command=confirm).pack(pady=5)
    input_window.grab_set()
    root.wait_window(input_window)
    return result[0] if result else None

# Liste aktualisieren
def refresh_list():
    game_listbox.delete(0, tk.END)
    for game in games:
        game_listbox.insert(tk.END, game["name"])

# GUI
root = tk.Tk()
root.title("Play Center")
root.iconbitmap("playcenter.ico")

frame = tk.Frame(root)
frame.pack(padx=10, pady=10)

game_listbox = tk.Listbox(frame, width=40, height=10)
game_listbox.pack(side=tk.LEFT, padx=(0, 5))

button_frame = tk.Frame(frame)
button_frame.pack(side=tk.LEFT)

tk.Button(button_frame, text="Start", width=15, command=lambda: start_game(games[game_listbox.curselection()[0]]["path"]) if game_listbox.curselection() else None).pack(pady=2)
tk.Button(button_frame, text="Add", width=15, command=add_game).pack(pady=2)
tk.Button(button_frame, text="Remove", width=15, command=delete_game).pack(pady=2)

games = load_games()
refresh_list()

root.mainloop()
